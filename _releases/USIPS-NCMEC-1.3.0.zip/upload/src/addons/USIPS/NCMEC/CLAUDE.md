# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What This Is

A XenForo 2.x addon (USIPS/NCMEC) that enables Electronic Service Providers to comply with 18 U.S.C. § 2258A — mandatory reporting of child sexual exploitation material (CSEM) to the National Center for Missing and Exploited Children via their CyberTipline API. See `_material/` for the NCMEC API docs, XSD schema, and relevant federal statutes.

Addon ID: `USIPS/NCMEC` — Title: "Anti-Child Abuse Tools by the USIPS"

## Development Environment

This addon is developed using the Docker-based XenForo dev environment at `/home/josh/Source/xf-docker/`. The addon source exists in two locations that must stay in sync:
- **Git repo (primary):** `/home/josh/Source/xf_kiwifarms/src/addons/USIPS/NCMEC`
- **Docker mount:** `/home/josh/Source/xf-docker/web/xenforo/src/addons/USIPS/NCMEC`

All XenForo CLI commands run from the xf-docker directory:

```bash
cd /home/josh/Source/xf-docker

# Install/upgrade/rebuild addon
./cmd.sh xf:addon-install USIPS/NCMEC
./cmd.sh xf:addon-upgrade USIPS/NCMEC
./cmd.sh xf:addon-rebuild USIPS/NCMEC

# Development import/export (sync _output/ ↔ database)
./cmd.sh xf-dev:import -a USIPS/NCMEC
./cmd.sh xf-dev:export -a USIPS/NCMEC

# Production export and release build
./cmd.sh xf-addon:export USIPS/NCMEC
./cmd.sh xf-addon:build-release USIPS/NCMEC

# Generate test data
./cmd.sh usips:generate-test-data

# Recompile templates (auto-detected in dev mode, but useful after import)
./cmd.sh xf-dev:recompile-templates
```

Templates in `_output/templates/` are auto-recompiled on page load in dev mode. All other `_output/` types (phrases, routes, class extensions, etc.) require `xf-dev:import` after editing.

## Version Scheme

`addon.json` uses `version_id: 1010200` = version `1.2.0` (MAJOR×1000000 + MINOR×1000 + PATCH×100). Upgrade steps in `Setup.php` use the method naming convention `upgrade{VersionId}Step{N}()`.

## Architecture

### Data Model (9 custom tables + 2 altered core tables)

The domain model centers on **Cases** containing **Incidents** which link to **Reports**:

```
CaseFile (xf_usips_ncmec_case)
├── Person (xf_usips_ncmec_person) — reporter / reported person
├── Incident (xf_usips_ncmec_incident)
│   ├── IncidentUser (xf_usips_ncmec_incident_user)
│   ├── IncidentContent (xf_usips_ncmec_incident_content) — polymorphic content_type/content_id
│   └── IncidentAttachmentData (xf_usips_ncmec_incident_attachment_data)
└── Report (xf_usips_ncmec_report) — one per subject user per case
    └── ReportFile (xf_usips_ncmec_report_file)
```

Plus `ApiLog (xf_usips_ncmec_api_log)` for all NCMEC API call audit logging.

Altered core tables:
- `xf_attachment_data` — added `usips_ncmec_incident_count` (denormalized)
- `xf_report` — added `emergency_report` flag

### Content Types

`IncidentContent` tracks content by type string. Supported: `post`, `thread`, `profile_post`, `conversation_message`, `xfmg_media`, `xfmg_album`, `xfmg_comment`, `resource_update`. Threads are NOT stored directly as content — only their first post, to avoid double-counting.

### Content Visibility Filtering

`Listener::finderSetup()` injects `NOT EXISTS` subqueries into all public-facing Finders for supported content types. Content in incidents is silently hidden from the public app but remains visible in Reports, Approval Queue, and Warnings routes, and always visible in Admin/CLI contexts.

### Key Services

| Service | Purpose |
|---------|---------|
| `Service\Incident\Creator` | Create incidents, associate/disassociate users, content, and attachments. Cascading operations collect all recent user content within a configurable time window. |
| `Service\Incident\ModeratorFlagger` | Flag content as CSAM from the approval queue |
| `Service\Incident\ReportFlagger` | Flag content as CSAM from the report center |
| `Service\Incident\AttachmentManager` | Manage attachment↔incident associations with denormalized counting |
| `Service\Report\Submitter` | Build NCMEC-compliant XML, upload files, stream data exports, finalize reports via the CyberTipline API |
| `Service\Api\Client` | Low-level NCMEC API HTTP client (Basic Auth, test/production environments, full request/response logging) |
| `Service\UserField` | Manages the `usips_ncmec_in_incident` custom user field |
| `Service\UserPromotion` | Instantly recalculates user group promotions when incident associations change |

### NCMEC API Integration

`Service\Api\Client` communicates with the CyberTipline REST API:
- **Test:** `https://exttest.cybertip.org/ispws`
- **Production:** `https://report.cybertip.org/ispws`
- Endpoints: `/status`, `/xsd`, `/submit` (open report), `/upload` (file), `/fileinfo` (file metadata), `/finish`, `/retract`

`Service\Report\Submitter` orchestrates the multi-step submission: open report → upload attachments → submit file details → export user/IP/changelog/content data as JSON → finish report → delete local content.

### Report Submission Job

`Job\FinalizeCase` is a multi-phase background job that processes case submission:
1. **Ban** each subject user
2. **Report** — open report with NCMEC API
3. **Files** — upload attachments in batches
4. **Export** — stream user data (users.json, ips.json, changelogs.json) and content by type
5. **Finish** — finalize report
6. **Cleanup** — delete content (posts, threads, attachments)

The job is resumable — it saves state and continues from the last phase if interrupted.

### XF Class Extensions

Extensions live under `XF/`, `XFMG/`, and `XFRM/` directories following XenForo's parallel-structure convention:

- **XF\Entity\Report** — adds `emergency_report` column
- **XF\Service\Report\CreatorService** — adds emergency handling (auto-hide content + priority notification)
- **XF\Service\Report\NotifierService** — emergency notification mode
- **XF\ControllerPlugin\ReportPlugin** — adds "Flag as CSAM" report type
- **XF\ApprovalQueue\\*** — adds "Flag as CSAM" action via `FlagCsamActionTrait`
- **XF\Finder\\***, **XFMG\Finder\\***, **XFRM\Finder\\*** — inject content visibility subqueries
- **XF\Repository\Ip** / **ChangeLog** — extend to collect data for NCMEC exports

### Emergency Report Flow

User submits report with emergency flag → `CreatorService` extension sets `emergency_report=1` → content auto-hidden → priority staff notification via `NotifierService` extension.

### Moderator CSAM Flagging Flow

Moderator flags content (approval queue or report center) → `ModeratorFlagger`/`ReportFlagger` finds or creates incident → collects user's recent content within time limit → associates user + content + attachments → sets `usips_ncmec_in_incident=1` user field → triggers instant user group promotion recalculation → closes related reports.

### Data Preservation (18 U.S.C. § 2703(f))

`Repository\Preservation` handles law enforcement data preservation requests. `Listener::entityPreDelete()` blocks deletion of content belonging to preserved users.
